WORLD-EDUCATION 2.0 — ELMANZY IMPERIAL EDITION
Paket aplikasi web progresif (PWA) — UPDATE 52
Biaya aplikasi dan alat: GRATIS. Tidak perlu langganan.

CARA PASANG DI ANDROID (PWA):
1. Unggah SELURUH isi folder ini ke hosting HTTPS gratis, misalnya GitHub Pages.
   Jangan unggah index.html saja. Sertakan manifest.webmanifest, sw.js, dan folder icons.
2. Buka URL HTTPS game di Chrome Android.
3. Pilih menu ⋮ Chrome > Install app / Tambahkan ke layar utama.
4. Jalankan ikon WORLD-EDUCATION dari layar utama.

CATATAN HOSTING GRATIS:
- GitHub Pages dapat dipakai gratis untuk situs publik sesuai batas dan ketentuan GitHub.
- Domain khusus tidak wajib; URL github.io sudah cukup.
- Paket ZIP ini belum dipublikasikan ke internet dan belum memiliki URL live.

OFFLINE:
- Service worker menyimpan shell aplikasi dan mencoba menyimpan index.html (~30 MB).
- Cache game 30 MB bergantung pada kuota penyimpanan browser/perangkat. Pastikan ruang kosong cukup.
- Website eksternal, server online, dan konten yang membutuhkan internet tetap perlu koneksi.

STATUS FORMAT:
- Ini PWA yang dapat dipasang dari browser, bukan APK native.
- PWA tidak memerlukan Play Store atau biaya signing APK.
- APK native opsional memerlukan proses build Android (Android Studio/SDK gratis), tetapi bukan hasil paket ini.

KREDIT: Elmanzy X CGPT
Knowledge Is Power.
