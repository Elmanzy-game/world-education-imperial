/* WORLD-EDUCATION 2.0 — ELMANZY IMPERIAL EDITION
   Offline-first shell with a quota-safe attempt to cache the large game file. */
const CACHE = 'world-education-imperial-v53';
const SHELL = ['./', './manifest.webmanifest', './icons/icon-192.png', './icons/icon-512.png'];
const GAME = './index.html';

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    // Keep the installable shell reliable even if the 30 MB game exceeds quota.
    await cache.addAll(SHELL);
    try {
      const response = await fetch(GAME, { cache: 'reload' });
      if (response.ok) await cache.put(GAME, response);
    } catch (error) {
      // Installation can still complete; offline game availability depends on quota.
      console.warn('Game file could not be cached during install:', error);
    }
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key.startsWith('world-education-imperial-') && key !== CACHE) {
        await caches.delete(key);
      }
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(request);
    const isGameDocument = request.mode === 'navigate' || url.pathname.endsWith('/index.html') || url.pathname.endsWith('/');

    if (isGameDocument) {
      try {
        const fresh = await fetch(request);
        if (fresh.ok) {
          try { await cache.put(request, fresh.clone()); } catch (error) {
            console.warn('Game cache update skipped (storage quota):', error);
          }
        }
        return fresh;
      } catch (error) {
        if (cached) return cached;
        const fallback = await cache.match(GAME);
        return fallback || Response.error();
      }
    }

    if (cached) return cached;
    try {
      const fresh = await fetch(request);
      if (fresh.ok && request.destination !== 'document') {
        try { await cache.put(request, fresh.clone()); } catch (_) {}
      }
      return fresh;
    } catch (error) {
      return cached || Response.error();
    }
  })());
});
