# WORLD-EDUCATION 2.0 — ELMANZY IMPERIAL EDITION (Offline Android)

Android WebView wrapper that bundles the complete UPDATE 52 HTML game in `app/src/main/assets/www/index.html`.

## Offline behavior
- The game HTML and its embedded assets are packaged inside the APK.
- No Internet permission is declared, so the app does not require a connection to launch the bundled game.
- Local browser storage is enabled for game progress/settings.
- Online-only features that call remote services (for example, remote 3D asset catalogs or a separately configured backend) will remain unavailable offline.

## Build with Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as an existing Android project.
3. Let Gradle sync finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.

## Build using GitHub Actions
Push this project to a GitHub repository, then open **Actions > Build WORLD-EDUCATION APK > Run workflow**. Download the generated APK from the workflow run's **Artifacts** section.

Package: `com.elmanzy.worldeducation`  
Version: `2.0.52`  
Credits in game: **Elmanzy X CGPT**
